package com.amjad.valguide.di

import com.amjad.valguide.core.domain.usecase.AgentsInteractor
import com.amjad.valguide.core.domain.usecase.AgentsUseCase
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AppModule {

    @Binds
    @Singleton
    abstract fun provideAgentsUseCase(agentsInteractor: AgentsInteractor): AgentsUseCase

}