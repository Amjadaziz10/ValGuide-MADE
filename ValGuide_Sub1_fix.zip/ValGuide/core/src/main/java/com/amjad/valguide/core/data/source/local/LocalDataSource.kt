package com.amjad.valguide.core.data.source.local

import com.amjad.valguide.core.data.source.local.entitiy.AgentsEntitiy
import com.amjad.valguide.core.data.source.local.room.AgentsDao
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LocalDataSource @Inject constructor(private val agentsDao: AgentsDao) {

    fun getAllAgents(): Flow<List<AgentsEntitiy>> = agentsDao.getAllAgents()

    fun getFavoriteAgents(): Flow<List<AgentsEntitiy>> = agentsDao.getFavoriteAgents()

    suspend fun insertAgents(agentsList: List<AgentsEntitiy>) = agentsDao.insertAgents(agentsList)

    fun setFavoriteAgents(agents: AgentsEntitiy, newState: Boolean) {
        agents.favorite = newState
        agentsDao.updateFavoriteAgents(agents)
    }
}