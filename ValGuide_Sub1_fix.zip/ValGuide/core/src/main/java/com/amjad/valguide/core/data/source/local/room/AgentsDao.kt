package com.amjad.valguide.core.data.source.local.room

import androidx.room.*
import com.amjad.valguide.core.data.source.local.entitiy.AgentsEntitiy
import kotlinx.coroutines.flow.Flow

@Dao
interface AgentsDao {
    @Query("SELECT * FROM agents")
    fun getAllAgents(): Flow<List<AgentsEntitiy>>

    @Query("SELECT * FROM agents where favorite = 1")
    fun getFavoriteAgents(): Flow<List<AgentsEntitiy>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAgents(agent: List<AgentsEntitiy>)

    @Update
    fun updateFavoriteAgents(tourism: AgentsEntitiy)

}