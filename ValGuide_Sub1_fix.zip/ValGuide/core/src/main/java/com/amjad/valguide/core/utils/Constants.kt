package com.amjad.valguide.core.utils

object Constants {
    val EXTRA_DATA = "DATA"
}